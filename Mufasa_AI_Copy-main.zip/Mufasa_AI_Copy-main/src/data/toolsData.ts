
// Re-export the expanded tools data as the main tools data
export { default } from './expandedToolsData';
export type { Tool } from '@/components/cards/ToolCard';
